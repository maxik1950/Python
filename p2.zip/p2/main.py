# import math
#
# z=int(input())
# if z<0:
#     x=z
# else:
#     x=math.sin(z)
# y=(2/3)*math.pow(math.sin(x),2)-(3/4)*math.pow(math.cos(x),2)
# print (y)
#
# x=int(input())
# y=int(input())
# z=int(input())
# if y<z:
#     min1=y
# else:
#     min1=z
# if x<y:
#     min2=x
# else:
#     min2=y
# if min1>min2:
#     max1=min1
# else:
#     max1=min1
# m=min1/max1
# print(m)
#
# m=min(y,z)/max(min(x,y),min(y,z))
# print(m)

# x=int(input())
# y=int(input())
# if x<y:
#     print(x,y)
# else:
#     z=x
#     x=y
#     y=z
#     print(f'x={x} меньше y={y}')

x=int(input())
y=int(input())
if x!=y:
    z=x+y
    f=x*y
    if x<y:
        x=z
        y=f
    else:
        y=z
        x=f
    print(x,y)
else:
    print("равны")