#a = "Максим"
#print (a)
#myAge=input("Введите свой возраст")
#print("Ваш возраст",myAge)

#good=True
#print(good)

#Alive = False
#print(Alive)

#myAge = 16
#print("Возраст", myAge)

#myCount = 76
#print("Количество", myCount16)

#myHeight = 1.67
#pi = 3.14
#weight = 50.
#print(myHeight)
#print(pi)
#print(weight)

import  math
a = int(input())
z1 = math.cos(a)+math.cos(2*a)+math.cos(6*a)+math.cos(7*a)
z2 = math.


