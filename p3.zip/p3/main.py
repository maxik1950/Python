# import math
#
# a=-1.9
# b=2.7
# h=0.3
# while a<b:
#     y=(math.pow(a,2)/4+a/2-3)*math.pow(math.e,a/2)
#     print(y)
#     a+=h
import math

a=0,1
b=1,0
h=0,1
j=0
while a<=b:
    s=(2*a+1)/math.factorial(a)*math.pow(a,2*a)
    j